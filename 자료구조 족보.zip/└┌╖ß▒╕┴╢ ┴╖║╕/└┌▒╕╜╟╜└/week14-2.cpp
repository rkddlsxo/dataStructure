//#include <iostream>
//#include <vector>
//#include <queue>
//using namespace std;
//
//vector <int> v[101];
//bool isVisited[101] = { false };
//int minimum = 101; // int maximum = 0;
//
//void ans(int vertex) {
//    if (vertex < minimum) minimum = vertex; // if(vertex > maximum) maximum = vertex;
//    isVisited[vertex] = true;
//    for (int i : v[vertex]) {
//        if (!isVisited[i]) {
//            ans(i);
//        }
//    }
//}
//
//int main() {
//    int t;
//    cin >> t;
//    for (int i = 0; i < t; i++) {
//        int n, m, k;
//        cin >> n >> m >> k;
//        for (int j = 0; j < m; j++) {
//            int a, b;
//            cin >> a >> b;
//            v[a].push_back(b);
//            v[b].push_back(a);
//        }
//        for (int j = 0; j < k; j++) {
//            minimum = 101; // maximum = 0;
//            int c;
//            cin >> c;
//            ans(c);
//            cout << minimum << endl; // cout << maximum << endl;
//            for (int x=  0; x < 101; x++) {
//                isVisited[x] = false;
//            }
//        }
//        for (int j = 0; j <= 100; j++) {
//            v[j].clear();
//        }
//    }
//}

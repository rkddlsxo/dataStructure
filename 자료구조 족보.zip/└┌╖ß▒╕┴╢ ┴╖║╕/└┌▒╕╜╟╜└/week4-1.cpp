//#include <iostream>
//#include <string>
//using namespace std;
//
//class arrayQueue {
//private :
//	int* arr;
//	int capacity;
//	int frontIndex;
//	int rearIndex;
//	int n;
//public :
//	arrayQueue(int capacity) {
//		this->capacity = capacity;
//		arr = new int[capacity];
//		frontIndex = rearIndex = 0;
//		n = 0;
//	}
//	bool empty() {
//		return (n == 0);
//	}
//	int size() {
//		return n;
//	}
//	void front() {
//		if (empty()) {
//			cout << "Empty" << endl;
//			return;
//		}
//		cout << arr[frontIndex]<< endl;
//	}
//	void rear() {
//		if (empty()) {
//			cout << "Empty" << endl;
//			return;
//		}
//		else {
//			cout << arr[rearIndex-1] << endl;
//		}
//	}
//	void enqueue(int data) {
//		if (size() == capacity) {
//			cout << "Full" << endl;
//			return;
//		}
//		else {
//			arr[rearIndex] = data;
//			rearIndex = (rearIndex + 1) % capacity;
//			n++;
//		}
//	}
//	void dequeue() {
//		if (empty()) {
//			cout << "Empty" << endl;
//			return;
//		}
//		else {
//			arr[frontIndex] = 0;
//			frontIndex = (frontIndex + 1) % capacity;
//			n--;
//		}
//	}
//	void print() {
//		if (empty()) {
//			return;
//		}
//		for (int i = 0; i < capacity; i++) {
//			cout << arr[i] << " ";
//		}
//	}
//};
//
//struct node {
//	int data;
//	node* next;
//};
//class listQueue {
//private :
//	node* frontNode;
//	node* rearNode;
//	int n;
//public :
//	listQueue() {
//		frontNode = rearNode = NULL;
//		n = 0;
//	}
//	bool empty() {
//		return (n == 0);
//	}
//	int size() {
//		return n;
//	}
//	void front() {
//		if (empty()) {
//			cout << "Empty" << endl;
//			return;
//		}
//		cout << frontNode->data << endl;
//	}
//	void rear() {
//		if (empty()) {
//			cout << "Empty" << endl;
//			return;
//		}
//		else {
//			cout << rearNode->data << endl;
//		}
//	}
//	void enqueue(int data) {
//		node* newNode = new node;
//		newNode->data = data;
//		newNode->next = NULL;
//		if (empty()) {
//			frontNode = rearNode = newNode;
//		}
//		else {
//			rearNode->next = newNode;
//			rearNode = newNode;
//		}
//		n++;
//	}
//	void dequeue() {
//		if (empty()) {
//			cout << "Empty" << endl;
//			return;
//		}
//		node* curNode = frontNode;
//		if (n == 1) {
//			frontNode = rearNode = NULL;
//		}
//		else {
//			frontNode = frontNode->next;
//		}
//		delete curNode;
//		n--;
//	}
//};
//
//int main() {
//	// 4-1 �� ����
//	/*int  T;
//	cin >> T;
//	listQueue lq;
//	for (int i = 0; i < T; i++) {
//		string s;
//		cin >> s;
//		if (s == "size") {
//			cout << lq.size() << endl;
//		}
//		else if (s == "isEmpty") {
//			if (lq.empty() == 1) {
//				cout << "True" << endl;
//			}
//			else {
//				cout << "False" << endl;
//			}
//			
//		}
//		else if (s == "front") {
//			lq.front();
//		}
//		else if (s == "rear") {
//			lq.rear();
//		}
//		else if (s == "enqueue") {
//			int value;
//			cin >> value;
//			lq.enqueue(value);
//		}
//		else if (s == "dequeue") {
//			lq.dequeue();
//		}
//	}
//	return 0;*/
//
//	// 4-3 �� ����
//	int  N ,T;
//	cin >> N >> T;
//	arrayQueue aq(N);
//	for (int i = 0; i < T; i++) {
//	string s;
//	cin >> s;
//	if (s == "size") {
//		cout << aq.size() << endl;
//	}
//	else if (s == "isEmpty") {
//		if (aq.empty() == 1) {
//			cout << "True" << endl;
//		}
//		else {
//			cout << "False" << endl;
//		}
//	}
//	else if (s == "front") {
//		aq.front();
//	}
//	else if (s == "rear") {
//		aq.rear();
//	}
//	else if (s == "enqueue") {
//		int value;
//		cin >> value;
//		aq.enqueue(value);
//	}
//	else if (s == "dequeue") {
//		aq.dequeue();
//	}
//	else if (s == "print") {
//		aq.print();
//	}
//}
//return 0;
//}
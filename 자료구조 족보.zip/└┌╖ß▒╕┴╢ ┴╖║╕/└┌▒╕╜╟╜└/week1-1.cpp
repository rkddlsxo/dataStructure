//#include <iostream>
//#include <string>
//using namespace std;
//
//class Array {
//private:
//	int* arr; // �迭
//	int N; // �迭�� ũ��
//public:
//	Array(int sz) {
//		this->N = sz; // �迭 ũ�� �ʱ�ȭ
//		this->arr = new int[N]; // ũ�� sz �迭
//		for (int i = 0; i < sz; i++) { // �迭 ��� 0 �ʱ�ȭ
//			arr[i] = 0;
//		}
//	}
//	/*void find(int num) {
//		int number=0;
//		for (int i = 0; i < N; i++) {
//			if (arr[i] == num) {
//				number++;
//			}
//		}
//		cout << number << endl;
//	}*/
//	void find(int num) {
//		int val = 0;
//	for (int i = 0; i < N; i++) {
//		if (arr[i] == num) {
//			val++;
//			cout << i;
//		}
//		if (val > 1) {
//			break;
//		}
//	}
//	if (val == 0) {
//		cout << -1 << endl;
//	}
//}
//
//	void add(int idx, int value) { // �迭 ����
//		for (int i = N - 2; i >= idx; i--) {
//			arr[i + 1] = arr[i];
//		}
//		arr[idx] = value;
//	}
//
//	void set(int idx, int value) { // �迭�� �� �ش�
//		arr[idx] = value;
//	}
//	void print() {
//		for (int i = 0; i < N; i++) { // �迭 ���
//			cout << arr[i] << " ";
//		}
//		cout << endl;
//	}
//	void remove(int idx) { // �迭 ����
//		for (int i = idx + 1; i < N; i++) {
//			arr[i - 1] = arr[i];
//		}
//		arr[N - 1] = 0;
//	}
//};
//
//
//int main() {
//	int T, N;
//	cin >> T >> N;
//	Array myArr(N);
//	for (int i = 0; i < T; i++) {
//		string s;
//		int index, value;
//		cin >> s;
//		if (s == "add") {
//			cin >> index >> value;
//			myArr.add(index, value);
//		}
//		else if (s == "print") {
//			myArr.print();
//		}
//		else if (s == "set") {
//			cin >> index >> value;
//			myArr.set(index, value);
//		}
//		else if (s == "find") {
//			cin >> value;
//			myArr.find(value);
//		}
//		else if (s == "remove") {
//			cin >> index;
//			myArr.remove(index);
//		}
//	}
//
//	
//	return 0;
//}
//
//

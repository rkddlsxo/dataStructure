//#include <iostream>
//#include <string>
//using namespace std;
//
//struct node {
//	node* prev;
//	node* next;
//	int data;
//};
//class nodeList {
//private:
//	node* pos = begin();
//	node* header;
//	node* trailer;
//	int n;
//public:
//	nodeList() {
//		header = new node;
//		trailer = new node;
//		header->next = trailer;
//		trailer->prev = header;
//		header->prev = trailer->next = NULL;
//		n = 0;
//	}
//	bool empty() {
//		return (n == 0);
//	}
//	int size() {
//		return n;
//	}
//	node* begin() {
//		return header->next;
//	}
//	node* end() {
//		return trailer;
//	}
//	void insert(int data) {
//		node* newNode = new node;
//		newNode->data = data;
//		newNode->prev = pos->prev;
//		newNode->next = pos;
//		pos->prev->next = newNode;
//		pos->prev = newNode;
//		n++;
//	}
//	//void insertFront(int data) {
//	//	insert(begin(), data);
//	//}
//	//void insertBack(int data) {
//	//	insert(end(), data);
//	//}
//	void erase() {
//		if (empty()) {
//			cout << "Empty" << endl;
//		}
//		pos->prev->next = pos->next;
//		pos->next->prev = pos->prev;
//		delete pos;
//		n--;
//	}
//	//void eraseFront() {
//	//	erase(begin());
//	//}
//	//void eraseBack() {
//	//	erase(begin()->prev);
//	//}
//	void nextP() {
//		if (pos == trailer) {
//			return;
//		}
//		else if (pos != end()) {
//			pos = pos->next;
//		}
//	}
//	void prevP() {
//		if (pos == header->next) {
//			return;
//		}
//		else if (pos != begin()) {
//			pos = pos->prev;
//		}
//	}
//	void print() {
//		if (empty()) {
//			cout << "Empty" << endl;
//		}
//		for (node* c = begin(); c != end(); c = c->next) {
//			cout << c->data << " ";
//		}
//		cout << endl;
//	}
//	void upper(int data) {
//		int count = 0;
//		for (node* c = begin(); c != end(); c = c->next) {
//			if (data < c->data) {
//				count++;
//				cout << c << " ";
//			}
//		}
//		cout << endl;
//		if (count == 0) {
//			cout << -1 << endl;
//		}
//	}
//};
//
//
//int main() {
//	nodeList list;
//	int N;
//	cin >> N;
//	for (int i = 0; i < N; i++) {
//		string s;
//		cin >> s;
//		if (s == "upper") {
//			int e;
//			cin >> e;
//			list.upper(e);
//		}
//		else if (s == "print") {
//			list.print();
//		}
//		else if (s == "insert") {
//			int e;
//			cin >> e;
//			list.insert(e);
//		}
//		else if (s == "prevP") {
//			list.prevP();
//		}
//		else if (s == "nextP") {
//			list.nextP();
//		}
//		else if (s == "erase") {
//			list.erase();
//		}
//		else if (s == "begin") {
//			list.begin();
//		}
//		else if (s == "end") {
//			list.end();
//		}
//	}
//	return 0;
//}
//
//

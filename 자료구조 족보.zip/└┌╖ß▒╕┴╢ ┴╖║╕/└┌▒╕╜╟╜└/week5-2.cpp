//#include <iostream>
//#include <string>
//using namespace std;
//
//struct node {
//	int data;
//	node* prev;
//	node* next;
//};
//
//class nodeList {
//private:
//	node* header;
//	node* trailer;
//	int n;
//public:
//	nodeList() {
//		header = new node;
//		trailer = new node;
//		header->next = trailer;
//		trailer->prev = header;
//		header->prev = trailer->next = NULL;
//		n = 0;
//	}
//	bool empty() {
//		return (n == 0);
//	}
//	int size() {
//		return n;
//	}
//	node* begin() {
//		return header->next;
//	}
//	node* end() {
//		return trailer;
//	}
//	void insert(node* pos, int data) {
//		node* newNode = new node;
//		newNode->data = data;
//		newNode->prev = pos->prev;
//		newNode->next = pos;
//		pos->prev->next = newNode;
//		pos->prev = newNode;
//		n++;
//	}
//	void erase(node* pos) {
//		pos->prev->next = pos->next;
//		pos->next->prev = pos->prev;
//		delete pos;
//		n--;
//	}
//	void eraseBack() {
//		erase(end()->prev);
//	}
//	void sum() {
//		node* tempNode = new node;
//		tempNode = header->next;
//		for (int i = 0; i < n; i++) {
//			if (i == 0) {
//				cout << tempNode->data + tempNode->next->data << " ";
//			}
//			else if (i == n - 1) {
//				cout << tempNode->data + tempNode->prev->data << " ";
//			}
//			else {
//				cout << tempNode->prev->data + tempNode->data + tempNode->next->data << " ";
//			}
//			tempNode = tempNode->next;
//		}
//	}
//	void minus() {
//		node* tempNode = new node;
//		tempNode = header->next;
//		for (int i = 0; i < n; i++) {
//			if (i == 0) {
//				if (tempNode->data > tempNode->next->data) {
//					cout << tempNode->data - tempNode->next->data << " ";
//				}
//				else {
//					cout << tempNode->next->data - tempNode->data << " ";
//				}
//			}
//			else if (i == n - 1) {
//				if (tempNode->data > tempNode->prev->data) {
//					cout << tempNode->data - tempNode->prev->data << " ";
//				}
//				else {
//					cout << tempNode->prev->data - tempNode->data << " ";
//				}
//			}
//			else {
//				if (tempNode->prev->data > tempNode->data && tempNode->data > tempNode->next->data) {
//					cout << tempNode->prev->data - tempNode->next->data << " ";
//				}
//				else if (tempNode->prev->data > tempNode->next->data && tempNode->next->data > tempNode->data) {
//					cout << tempNode->prev->data - tempNode->data << " ";
//				}
//				else if (tempNode->data > tempNode->next->data && tempNode->next->data > tempNode->prev->data) {
//					cout << tempNode->data - tempNode->prev->data << " ";
//				}
//				else if (tempNode->data > tempNode->prev->data && tempNode->prev->data > tempNode->next->data) {
//					cout << tempNode->data - tempNode->next->data << " ";
//				}
//				else if (tempNode->next->data > tempNode->data && tempNode->data > tempNode->prev->data) {
//					cout << tempNode->next->data - tempNode->prev->data << " ";
//				}
//				else {
//					cout << tempNode->next->data - tempNode->data << " ";
//				}
//			}
//			tempNode = tempNode->next;
//		}
//	}
//
//};
//
//int main() {
//	int t;
//	cin >> t;
//	for (int i=0; i < t; i++) {
//		int n;
//		cin >> n;
//		nodeList list;
//		for (int j= 0; j < n; j++) {
//			int e;
//			cin >> e;
//			list.insertBack(e);
//		}
//		list.minus();
//		cout << endl;
//	}
//}
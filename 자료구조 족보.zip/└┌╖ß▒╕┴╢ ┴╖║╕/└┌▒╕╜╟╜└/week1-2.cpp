//#include <iostream>
//#include <string>
//using namespace std;
//
//class Array {
//private:
//	int* arr; // �迭
//	int N; // �迭�� ũ��
//public:
//	Array(int sz) {
//		this->N = sz; // �迭 ũ�� �ʱ�ȭ
//		this->arr = new int[N]; // ũ�� sz �迭
//		for (int i = 0; i < sz; i++) { // �迭 ��� 0 �ʱ�ȭ
//			arr[i] = 0;
//		}
//	}
//	void add(int idx, int value) { // �迭 ����
//		for (int i = N - 2; i >= idx; i--) {
//			arr[i + 1] = arr[i];
//		}
//		arr[idx] = value;
//	}
//
//	void leftShift(int idx) {
//		for (int i = 0; i < idx; i++) {
//			int tmp = arr[0];
//			for (int i = 0; i <= N-2; i++) {
//				arr[i] = arr[i+1];
//			}
//			arr[N-1] = tmp;
//		}
//	}
//
//	void rightShift(int idx) {
//		for (int i = 0; i < idx; i++) {
//			int tmp = arr[N - 1];
//			for (int i = N - 2; i >= 0; i--) {
//				arr[i + 1] = arr[i];
//			}
//			arr[0] = tmp;
//		}
//	}
//void reverse(int i, int j) {
//	int tempJ = j;
//	for (int k=i; k <= j / 2; k++) {
//		int temp = arr[k]; 
//		arr[k] = arr[tempJ];
//		arr[tempJ] = temp;
//		tempJ--;
//	}
//}
//	void print() {
//		for (int i = 0; i < N; i++) { 
//			cout << arr[i] << " ";
//		}
//		cout << endl;
//	}
//};
//
//
//int main() {
//
//	return 0;
//}

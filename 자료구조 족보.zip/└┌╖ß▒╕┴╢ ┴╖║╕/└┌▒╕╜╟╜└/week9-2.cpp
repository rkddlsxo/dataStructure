//#include <iostream>
//#include <string>
//#include <vector>
//using namespace std;
//
//struct compare {
//	bool operator()(const int& e1, const int& e2) const {
//		if (e1 % 2 ==  e2 % 2) { // solution 2
//			return e1 > e2;
//		}
//		else {
//			if (e1 % 2 == 0) {
//				return false;
//			}
//			if (e1 % 2 == 1) {
//				return true;
//			}
//		}
//		/*if (e1 % 2 == e2 % 2) { // solution 4
//			return e1 < e2;
//		}
//		else {
//			if (e1 % 2 == 1) {
//				return false;
//			}
//			if (e1 % 2 == 0) {
//				return true;
//			}
//		}*/
//	}
//};
//class unsortedSeqPQ {
//private :
//	vector<int> seq;
//public :
//	int size() {
//		return seq.size();
//	}
//	bool empty() {
//		return (seq.size() == 0);
//	}
//	void insert(int e) {
//		seq.push_back(e);
//	}
//	int min() {
//		if (empty()) return -1;
//		compare C;
//		int minVal = seq[0];
//
//		for (int i = 0; i < seq.size(); i++) {
//			if (C(seq[i], minVal)) {
//				minVal = seq[i];
//			}
//		}
//		return minVal;
//	}
//	void removeMin() {
//		if (empty()) return;
//
//		compare C;
//		int minIdx = 0;
//
//		for (int i = 0; i < seq.size(); i++) {
//			if (C(seq[i], seq[minIdx])) {
//				minIdx = i;
//			}
//		}
//		seq.erase(seq.begin() + minIdx);
//	}
//};
//
//class sortedSeqPQ {
//private:
//	vector<int> seq;
//public:
//	int size() {
//		return seq.size();
//	}
//	bool empty() {
//		return (seq.size() == 0);
//	}
//	void insert(int e) {
//		compare C;
//		int idx = 0;
//		for (int idx = 0; idx < seq.size(); idx++) {
//			if (C(seq[idx], e)) break;
//		}
//		seq.insert(seq.begin() + idx, e);
//	}
//	int min() {
//		if (empty()) return -1;
//
//		return seq.back();
//	}
//	void removeMin() {
//		if (empty()) return;
//
//		seq.pop_back();
//	}
//};
//int main() {
//	int t;
//	cin >> t;
//	for (int a = 0; a < t; a++) {
//		int n;
//		cin >> n;
//		vector<int> arr;
//		unsortedSeqPQ uq;
//		for (int i = 0; i < n; i++) {
//			int e;
//			cin >> e;
//			arr.push_back(e);
//		}
//		for (int i = 0; i < n; i++) {
//			uq.insert(arr[0]);
//			arr.erase(arr.begin());
//		}
//		for (int i = 0; i < n; i++) {
//			arr.push_back(uq.min());
//			uq.removeMin();
//		}
//		for (int i = 0; i < n; i++) {
//			cout << arr[i] << " ";
//		}
//		cout << endl;
//	}
//	return 0;
//}
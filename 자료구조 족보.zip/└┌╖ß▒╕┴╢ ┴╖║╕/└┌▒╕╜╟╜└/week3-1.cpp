//#include <iostream>
//#include <string>
//using namespace std;
//
//class arrayStack {
//private :
//   int* arr;
//   int capacity;
//   int topIndex;
//public :
//   arrayStack(int capacity) {
//      this->capacity = capacity;
//      arr = new int[capacity];
//      topIndex = -1;
//   }
//   bool empty(){
//      return (topIndex == -1);
//   }
//   int size(){
//      return topIndex + 1;
//   }
//   int top() {
//      if (empty()) {
//         return -1;
//      }
//      return arr[topIndex];
//   }
//   void push(int data) {
//      if (size() == capacity) {
//         return;
//      }
//      arr[++topIndex] = data;
//   }
//   void pop() {
//      if (empty()) {
//         return;
//      }
//      topIndex --;
//   }
//};
//
//struct node {
//    int data;
//    node* next;
//};
//class listStack {
//private:
//    node* topNode;
//    int n;
//public:
//    listStack() {
//        topNode = NULL;
//        n = 0;
//    }
//    bool empty() {
//        return(n == 0);
//    }
//    int size() {
//        return n;
//    }
//    int top() {
//        if (empty()) {
//            cout << -1 << endl;
//            return;
//       }
//        cout << topNode->data << endl;
//    }
//    void push(int data) {
//        node* newNode = new node;
//        newNode->data = data;
//        newNode->next = topNode;
//        topNode = newNode;
//        n++;
//    }
//    void pop() {
//        if (empty()) {
//            cout << -1 << endl;
//            return;
//       }
//        node* curNode = topNode;
//        topNode = topNode->next;
//        cout << curNode->data << endl;
//        delete curNode;
//        n--;
//
//    }
//};
//
//int main() {
//    listStack ls;
//    int N;
//    cin >> N;
//    for (int i = 0; i < N; i++) {
//        string s;
//        cin >> s;
//        if (s == "pop") {
//            ls.pop();
//        }
//        else if (s == "size") {
//            cout << ls.size() << endl;
//        }
//        if (s == "push") {
//            int data;
//            cin >> data;
//            ls.push(data);
//        }
//        if (s == "empty") {
//            if (ls.empty() == true) {
//                cout << 1 << endl;
//            }
//            else {
//                cout << 0 << endl;
//            }
//        }
//        if (s == "top") {
//            cout << ls.top() << endl;
//        }
//    }
//    return 0;
//}
//#include <iostream>
//#include <vector>
//#include <string>
//using namespace std;
//
//class heap {
//private:
//	vector<int> arr;
//	void swap(int idx1, int idx2) {
//		arr[0] = arr[idx1];
//		arr[idx1] = arr[idx2];
//		arr[idx2] = arr[0];
//	}
//	void upHeap(int idx) {
//		if (idx == 1) {
//			return;
//		}
//		int parent = idx / 2;
//		if (arr[parent] < arr[idx]) { // max <
//			swap(parent, idx);
//			upHeap(parent);
//		}
//	}
//	void downHeap(int idx) {
//		int left = 2 * idx;
//		int right = 2 * idx + 1;
//		int child;
//		if (left > size()) {
//			return;
//		}
//		else if (left == size()) {
//			child = left;
//		}
//		else {
//			if (arr[left] >= arr[right]) { // max >=
//				child = left;
//			}
//			else {
//				child = right;
//			}
//		}
//
//		if (arr[child] > arr[idx]) { // max >
//			swap(child, idx);
//			downHeap(child);
//		}
//	}
//public:
//	heap() {
//		arr.push_back(0);
//	}
//	int size() {
//		return arr.size() - 1;
//	}
//	bool empty() {
//		return (arr.size() == 1);
//	}
//	void pop() {
//		if (empty()) {
//			cout << -1 << endl;
//			return;
//		}
//		cout << arr[1] << endl;
//		swap(1, size());
//		arr.pop_back();
//		downHeap(1);
//	}
//	void insert(int e) {
//		arr.push_back(e);
//		upHeap(size());
//	}
//	int max() {
//		if (empty()) return -1;
//		return arr[1];
//	}
//	int min() {
//		if (empty()) return -1;
//		int min = arr[size() / 2];
//		for (int i = size() / 2; i < size(); i++) {
//			if (min > arr[i]) min = arr[i];
//		}
//		return min;
//	}
//	void removeMin() {
//		if (empty()) {
//			return;
//		}
//		swap(1, size());
//		arr.pop_back();
//		downHeap(1);
//	}  
//	void print() {
//		if (empty()) {
//			cout << -1 << endl;
//			return;
//		}
//		for (int i = 1; i <= size(); i++) {
//			cout << arr[i] << " ";
//		}
//		cout << endl;
//	}
//};
//int main() {
//	int t;
//	cin >> t;
//
//	for (int i = 0; i < t; i++) {
//		heap h;
//		int n, p;
//		cin >> n >> p;
//		for (int i = 0; i < n; i++) {
//			int a;
//			cin >> a;
//			h.insert(a);
//		}
//		int cnt = 0;
//		bool isNot = false;
//		while (h.max() < p) {
//			int a = h.max();
//			h.removeMin();
//			h.removeMin();
//			int c = h.max();
//			h.removeMin();
//			int d = (a + c) / 2;
//			h.insert(d);
//			cnt++;
//			if (h.size() <= 2) {
//				if (h.max() < p || h.min() < p) {
//					cout << "False" << endl;
//					isNot = true;
//					break;
//				}
//			}
//		}
//		if (isNot) continue;
//		cout << cnt << endl;
//		h.print();
//	}
//}

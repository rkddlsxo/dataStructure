//#include <iostream>
//#include <string>
//using namespace std;
//
//#define NOITEM 0
//#define ISITEM 1
//#define AVAILABLE 2
//
//int pow(int a, int b) {
//	int temp = a;
//	if (b == 0) return 1;
//	for (int i = 1; i < b; i++) {
//		a *= temp;
//	}
//	return a;
//}
//
//int valueCalculator(string value) {
//	int temp = 0;
//	for (int i{ 0 }; i < value.size(); i++) {
//		temp += (value[i] - 'a') * pow(26, i);
//	}
//	return temp;
//}
//
//
//struct entry {
//	int key;
//	string value;
//	int valid;
//	bool attendance;
//
//	entry() {
//		key = 0;
//		value = "";
//		valid = NOITEM;
//		attendance = false;
//	}
//
//	entry(int key, string value) {
//		this->key = key;
//		this->value = value;
//		valid = ISITEM;
//		attendance = false;
//	}
//
//	void erase() {
//		valid = AVAILABLE;
//	}
//};
//
//class hashTable {
//public:
//	hashTable(int N);
//	hashTable(int N, int M);
//	void put(int key, string value);
//	void erase(int key);
//	string find(int key);
//	bool findAttendance(int key);
//	void setAttendance(int key, bool a);
//
//private:
//	entry* table;
//	int capacity;
//	int divisor;
//	int hashFnc(int key);
//	int hashFnc2(int key);
//};
//
//hashTable::hashTable(int N) {
//	capacity = N;
//	table = new entry[capacity];
//	return;
//}
//
//hashTable::hashTable(int N, int M) {
//	capacity = N;
//	divisor = M;
//	table = new entry[capacity];
//	return;
//}
//
//int hashTable::hashFnc(int key) {
//	return key % capacity;
//}
//
//int hashTable::hashFnc2(int key) {
//	return 1; //double hashing : return divisor - (key % divisor);
//}
//
//void hashTable::put(int key, string value) {
//	int index = hashFnc(key);
//	int probe = 1;
//
//	while (table[index].valid == ISITEM && probe <= capacity) {
//		index = hashFnc(index + hashFnc2(key));
//		probe++;
//	}
//	if (probe > capacity) return;
//	table[index] = entry(key, value);
//	return;
//}
//
//void hashTable::erase(int key) {
//	int index = hashFnc(key);
//	int probe = 1;
//
//	while (table[index].valid != NOITEM && probe <= capacity) {
//		if (table[index].valid == ISITEM && table[index].key == key) {
//			table[index].erase();
//			return;
//		}
//		index = hashFnc(index + hashFnc2(key));
//		probe++;
//	}
//	return;
//}
//
//string hashTable::find(int key) {
//	int index = hashFnc(key);
//	int probe = 1;
//
//	while (table[index].valid != NOITEM && probe <= capacity) {
//		if (table[index].valid == ISITEM && table[index].key == key) {
//			return table[index].value;
//		}
//		index = hashFnc(index + hashFnc2(key));
//		probe++;
//	}
//	return "";
//}
//
//bool hashTable::findAttendance(int key) {
//	int index = hashFnc(key);
//	int probe = 1;
//
//	while (table[index].valid != NOITEM && probe <= capacity) {
//		if (table[index].valid == ISITEM && table[index].key == key) {
//			return table[index].attendance;
//		}
//		index = hashFnc(index + hashFnc2(key));
//		probe++;
//	}
//	return false;
//}
//
//void hashTable::setAttendance(int key, bool a) {
//	int index = hashFnc(key);
//	int probe = 1;
//
//	while (table[index].valid != NOITEM && probe <= capacity) {
//		if (table[index].valid == ISITEM && table[index].key == key) {
//			table[index].attendance = a;
//		}
//		index = hashFnc(index + hashFnc2(key));
//		probe++;
//	}
//	return;
//}
//
//int main() {
//	int t, cnt{ 0 };
//	cin >> t;
//	hashTable htNum(500000);
//	hashTable htName(500000);
//
//	for (int i{ 0 }; i < t; i++) {
//		string a, name;
//		int num;
//		cin >> a;
//		if (a == "add") {
//			cin >> num >> name;
//			htNum.put(num, name);
//			htName.put(valueCalculator(name), to_string(num));
//		}
//		else if (a == "delete") {
//			cin >> num;
//			string b = htNum.find(num);
//			if (htName.findAttendance(valueCalculator(b))) {
//				cnt--;
//			}
//			htName.erase(valueCalculator(b));
//			htNum.erase(num);
//		}
//		else if (a == "name") {
//			cin >> num;
//			cout << htNum.find(num) << "\n";
//		}
//		else if (a == "present") {
//			cin >> name;
//			string b = htName.find(valueCalculator(name));
//			if (b == "") {
//				cout << "Invalid\n";
//			}
//			else {
//				cout << b << "\n";
//				if (!htName.findAttendance(valueCalculator(name))) {
//					cnt++;
//					htName.setAttendance(valueCalculator(name), true);
//				}
//			}
//		}
//		else if (a == "absent") {
//			cin >> name;
//			string b = htName.find(valueCalculator(name));
//			if (b == "") {
//				cout << "Invalid\n";
//			}
//			else {
//				cout << b << "\n";
//				if (htName.findAttendance(valueCalculator(name))) {
//					cnt--;
//					htName.setAttendance(valueCalculator(name), false);
//				}
//			}
//		}
//	}
//	cout << cnt;
//}

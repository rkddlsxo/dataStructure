//#include <iostream>
//#include <string>
//using namespace std;
//
////class arrayQueue {
////private:
////	int* arr;
////	int capacity;
////	int frontIndex;
////	int rearIndex;
////	int n;
////public:
////	arrayQueue(int capacity) {
////		this->capacity = capacity;
////		arr = new int[capacity];
////		frontIndex = rearIndex = 0;
////		n = 0;
////	}
////	bool empty() {
////		return (n == 0);
////	}
////	int size() {
////		return n;
////	}
////	int front() {
////		if (empty()) {
////			return -1;
////		}
////		return arr[frontIndex];
////	}
////	void enqueue(int data) {
////		if (size() == capacity) {
////			return;
////		}
////		arr[rearIndex] = data;
////		rearIndex = (rearIndex + 1) % capacity;
////		n++;
////	}
////	void dequeue() {
////		if (empty()) {
////			return;
////		}
////		frontIndex = (frontIndex + 1) % capacity;
////		n--;
////	}
////};
//
//struct node {
//	int data;
//	node* next;
//};
//class listQueue {
//private:
//	node* frontNode;
//	node* rearNode;
//	int n;
//public:
//	listQueue() {
//		frontNode = rearNode = NULL;
//		n = 0;
//	}
//	bool empty() {
//		return (n == 0);
//	}
//	int size() {
//		return n;
//	}
//	int front() {
//		if (empty()) {
//			return -1;
//		}
//		return frontNode->data;
//	}
//	void scorePlus(int num) {
//		if (empty()) {
//			return;
//		}
//		frontNode->data += num;
//	}
//	
//	void enqueue(int data) {
//		node* newNode = new node;
//		newNode->data = data;
//		newNode->next = NULL;
//		if (empty()) {
//			frontNode = rearNode = newNode;
//		}
//		else {
//			rearNode->next = newNode;
//			rearNode = newNode;
//		}
//		n++;
//	}
//	void dequeue() {
//		if (empty()) {
//			return;
//		}
//		node* curNode = frontNode;
//		if (size() == 1) {
//			frontNode = rearNode = NULL;
//		}
//		else {
//			frontNode = frontNode->next;
//		}
//		delete curNode;
//		n--;
//	}
//};
//
//int main() {
//	listQueue player1;
//	listQueue player2;
//	int T;
//	cin >> T;
//	for (int round = 0; round < T; round++) {
//		int N;
//		cin >> N;
//		int score1 = 0;
//		int score2 = 0;
//		for (int i = 0; i < N; i++) {
//			int num;
//			cin >> num;
//			player1.enqueue(num);
//		}
//		for (int j = 0; j < N; j++) {
//			int num;
//			cin >> num;
//			player2.enqueue(num);
//		}
//		for (int k = 0; k < N; k++) {
//			int p1 = player1.front();
//			player1.dequeue();
//			int p2 = player2.front();
//			player2.dequeue();
//			int res;
//			if (p1 - p2 >= 0) {
//				res = p1 - p2;
//				score1++;
//				player2.scorePlus(res);
//				cout << "Round" << k + 1 << " P1 " << res << endl;
//			}
//			else {
//				res = p2 - p1;
//				score2++;
//				player1.scorePlus(res);
//				cout << "Round" << k + 1 << " P2 " << res << endl;
//			}
//		}
//		if (score1 > score2) {
//			cout << "Winner P1" << endl;
//		}
//		else if (score1 == score2) {
//			cout << "Draw" << endl;
//		}
//		else if (score1<score2)	{
//			cout << "Winner P2" << endl;
//		}
//	}
//	return 0;
//}
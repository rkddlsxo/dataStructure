//#include <iostream>
//#include <string>
//using namespace std;
//
//struct node {
//    int data;
//    node* next;
//};
//
//class listStack {
//public:
//    listStack();
//    bool empty();
//    int size();
//    int top();
//    void push(int data);
//    void pop();
//
//private:
//    node* topNode;
//    int listSize;
//};
//
//listStack::listStack() {
//    topNode = NULL;
//    listSize = 0;
//}
//
//bool listStack::empty() {
//    if (listSize == 0) {
//        return true;
//    }
//    else { return false; }
//}
//
//int listStack::size() {
//    return listSize;
//}
//
//int listStack::top() {
//    if (empty()) {
//        return -1;
//    }
//    return topNode->data;
//}
//
//void listStack::push(int data) {
//    node* newNode = new node();
//    newNode->data = data;
//    newNode->next = topNode;
//    topNode = newNode;
//    listSize++;
//}
//
//void listStack::pop() {
//    if (empty()) {
//        return;
//    }
//    node* curNode = new node();
//    curNode = topNode;
//    topNode = topNode->next;
//    delete curNode;
//    listSize--;
//}
//
////isdigit(a[0]) �� ����� ���ڿ� �������ε� Ǯ��� 
//
//void postfixToinfix(string a) {
//    listStack stack;
//    for (int i{ 0 }; i < a.size(); i++) {
//        if (a[i] == '+' || a[i] == '-') { //�����ڶ��
//            while (!stack.empty()) {
//                if (stack.top() == 1) { cout << "+"; }
//                if (stack.top() == 2) { cout << "-"; }
//                if (stack.top() == 3) { cout << "*"; }
//                stack.pop();
//            }
//            if (a[i] == '+') { stack.push(1); }
//            if (a[i] == '-') { stack.push(2); }
//        }
//        else if (a[i] == '*') {
//            while (stack.top() == 3) {
//                cout << "*";
//                stack.pop();
//            }
//            stack.push(3);
//        }
//        else if (a[i] != '(' && a[i] != ')') { //�ǿ����ڶ��
//            cout << a[i];
//        }
//    }
//    while (!stack.empty()) {
//        if (stack.top() == 1) { cout << "+"; }
//        if (stack.top() == 2) { cout << "-"; }
//        if (stack.top() == 3) { cout << "*"; }
//        stack.pop();
//    }
//    cout << "\n";
//}
//
//int main() {
//    // ����ǥ��� -> ����ǥ��� ���
//    int t{ 0 };
//    cin >> t;
//    string postFix;
//    for (int i{ 0 }; i < t; i++) {
//        cin >> postFix;
//        postfixToinfix(postFix);
//    }
//}
//#include <iostream>
//#include <vector>
//using namespace std;
//
//vector<int> v[101];
//bool isVisited[101];
//vector<int> ans;
//
//void dfs(int vertex) {
//    ans.push_back(vertex);
//    isVisited[vertex] = true;
//    for (int i : v[vertex]) {
//        if (!isVisited[i]) {
//            dfs(i);
//        }
//    }
//}
//
//int main() {
//    int t;
//    cin >> t;
//    for (int i = 0; i < t; i++) {
//        int n, m;
//        cin >> n >> m;
//        for (int j = 0; j < m; j++) {
//            int a, b;
//            cin >> a >> b;
//            v[a].push_back(b);
//            v[b].push_back(a);
//        }
//        dfs(1);
//        for (int j = 0; j < ans.size(); j += 2) //Ȧ����°�� ���
//            cout << ans[j] << " ";
//        for (int j = 0; j <= 100; j++) {
//            isVisited[j] = false;
//            v[j].clear();
//        }
//        ans.clear();
//        cout << endl;
//    }
//}
//
//#include <iostream>
//#include <vector>
//#include <queue>
//
//using namespace std;
//
//vector<int> v[101];
//bool isVisited[101];
//vector<int> ans;
//
//void bfs(int vertex) {
//    queue<int> q;
//    q.push(vertex);
//    ans.push_back(vertex);
//    isVisited[vertex] = true;
//
//    while (!q.empty()) {
//        for (int i : v[q.front()]) {
//            if (!isVisited[i]) {
//                q.push(i);
//                ans.push_back(i);
//                isVisited[i] = true;
//            }
//        }
//        q.pop();
//    }
//
//}
//
//int main() {
//    int t;
//    cin >> t;
//    for (int i=0; i < t; i++) {
//        int n, m;
//        cin >> n >> m;
//        for (int j=0; j < m; j++) {
//            int a, b;
//            cin >> a >> b;
//            v[a].push_back(b);
//            v[b].push_back(a);
//        }
//        bfs(1);
//        for (int j=0;; j < ans.size(); j += 2) //Ȧ����°�� ���
//            cout << ans[j] << " ";
//        for (int j=0;; j <= 100; j++) {
//            isVisited[j] = false;
//            v[j].clear();
//        }
//        ans.clear();
//       cout << endl;
//    }
//}